# Overview
This mod adds a discharge defense equipment to the game that automatically triggers when enemies are nearby. It can be crafted by combining a regular discharge defense with a remote and an advanced circuit.

---------------------
# Translation
Help translate Automatic Discharge Defense to more languages: https://crowdin.com/project/factorio-mods-localization
Currently available locale:
- English (en)
- German (de)
- Polish (pl)
- Russian (ru)
- Ukrainian (uk)

---------------------
# Compatibility
There are currently no known mod compatibility issues. To report a compatibility issue, please make a post on the discussion page.

---------------------
# License
Automatic Discharge Defense © 2023 by asher_sky is licensed under Attribution-NonCommercial-ShareAlike 4.0 International.
To view a copy of this license, visit http://creativecommons.org/licenses/by-nc-sa/4.0/