# Overview
This mod adds a discharge defense equipment that automatically triggers when enemies are nearby. It can be crafted by combining a standard discharge defense with a remote and an advanced circuit.

---------------------
# Translation
Help translate Automatic Discharge Defense to more languages: https://crowdin.com/project/factorio-mods-localization
Currently available locale:
🇺🇸 English (en), 🇩🇪 German (de), 🇫🇷 French (fr), 🇵🇱 Polish (pl), 🇷🇺 Russian (ru), 🇺🇦 Ukrainian (uk), 🇨🇳 Chinese (zh-CN)

---------------------
# Compatibility
There are currently no known mod compatibility issues. To report a compatibility issue, please make a post on the discussion page.

---------------------
# License
Automatic Discharge Defense © 2024 by asher_sky is licensed under Attribution-NonCommercial-ShareAlike 4.0 International.
To view a copy of this license, visit http://creativecommons.org/licenses/by-nc-sa/4.0/
